var map = L.map('map', {maxZoom: 18}).setView([52.4095,16.931], 12);

// Pluginy

// Dodanie Geokodera
L.Control.geocoder().addTo(map);


// Dodanie funkcji Drukowania
L.easyPrint({
	title: 'Drukuj',
	elementsToHide: 'p, h2, .gitButton'
}).addTo(map);


// Dodanie funkcji Lokalizacji
L.easyLocation({
	title: 'Geokolalizacja',
	elementsToHide: 'p, h2, .gitButton'
}).addTo(map);


// Funkcja do dodawania markerów
L.DomEvent.disableClickPropagation(L.DomUtil.get('marker'))




// Switcher z warstawmi
// Dodanie kolejnych warstw


var mapnik = L.tileLayer('http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png')
mapnik.addTo(map)

var blackandwhite = L.tileLayer('http://{s}.tiles.wmflabs.org/bw-mapnik/{z}/{x}/{y}.png')

var topo = L.tileLayer('http://{s}.tile.opentopomap.org/{z}/{x}/{y}.png')

var Esri = L.tileLayer('http://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}')

var Rower = L.tileLayer('http://{s}.tiles.wmflabs.org/hikebike/{z}/{x}/{y}.png')
 



var basemaps = {
	'Mapnik': mapnik,
	'OSM B&W': blackandwhite,
	'Topo' : topo,
	'Esri' : Esri,
	'Rower' : Rower
}


var ficzery = L.featureGroup()
ficzery.addTo(map)
var overlays = {
  'Markery': ficzery
}
L.control.layers(basemaps, overlays).addTo(map)


// Dodawanie markerów
var czymoznaklikac = false
var color = ''
var popupYear = ''

map.on('click', function(e){
  if(czymoznaklikac == true){
    var circle = new L.circleMarker(e.latlng, {
      fillColor: color,
      fillOpacity: 1,
    })
    circle.bindPopup('Rok: '+popupYear)
    ficzery.addLayer(circle)
  }
})

zmienkolory = function(year){
  czymoznaklikac = true
  if(year == '2017'){
    color = 'red'
  }else if(year == '2016'){
    color = 'orange'
  }else{
    color = 'yellow'
  }
  
  
  // ustawienie zmiennej popupYear na aktualnie wybrany rok
  popupYear = year
}
stopklikanie = function(){
  czymoznaklikac = false
}